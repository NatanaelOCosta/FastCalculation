package br.edu.scl.ifsp.sdm.fastcalculation

object Extras {
    const val EXTRA_SETTINGS = "EXTRA_SETTINGS"
}
package br.edu.scl.ifsp.sdm.fastcalculation

interface OnPlayGame {
    fun onPlayGame()
}